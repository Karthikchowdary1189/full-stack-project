import paho.mqtt.client as mqtt

client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)  # Use version 2 to avoid warning
client.connect("test.mosquitto.org", 1883, 60)

client.publish("home/test", "Hello from MQTT Publisher!")
print("📤 Message sent!")
client.disconnect()
