import schedule
import time
import paho.mqtt.client as mqtt

broker = "test.mosquitto.org"
topic = "home/automation"

client = mqtt.Client()
client.connect(broker)

# Define scheduled tasks
def turn_on_lights():
    client.publish(topic, "ON")
    print("💡 Lights turned ON (Scheduled)")

def turn_off_lights():
    client.publish(topic, "OFF")
    print("💡 Lights turned OFF (Scheduled)")

# Schedule tasks
schedule.every().day.at("18:00").do(turn_on_lights)
schedule.every().day.at("06:00").do(turn_off_lights)

print("⏳ Scheduling tasks...")

while True:
    schedule.run_pending()
    time.sleep(1)
