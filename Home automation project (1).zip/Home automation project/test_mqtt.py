import paho.mqtt.client as mqtt

def on_connect(client, userdata, flags, rc):
    if rc == 0:
        print("✅ MQTT is installed and connected successfully!")
    else:
        print(f"⚠️ Connection failed with code {rc}")

client = mqtt.Client()

try:
    client.connect("test.mosquitto.org", 1883, 60)  # Public test MQTT broker
    client.loop_start()
except Exception as e:
    print(f"❌ MQTT not working: {e}")
