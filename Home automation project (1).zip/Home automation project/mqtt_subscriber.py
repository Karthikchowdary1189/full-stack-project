import paho.mqtt.client as mqtt

def on_message(client, userdata, message):
    print(f"📩 Message received: {message.payload.decode()} on topic {message.topic}")

client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)  # Use version 2 to avoid the warning
client.on_message = on_message

client.connect("test.mosquitto.org", 1883, 60)

client.subscribe("home/test")

print("📡 Listening for messages on 'home/test'...")
client.loop_forever()
