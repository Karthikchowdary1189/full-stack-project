import speech_recognition as sr
import paho.mqtt.client as mqtt

# MQTT Broker details
broker = "test.mosquitto.org"
topic = "home/automation"

# Initialize MQTT Client
client = mqtt.Client()
client.connect(broker)

def recognize_speech():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("🎙️ Speak your command...")
        recognizer.adjust_for_ambient_noise(source)
        audio = recognizer.listen(source)

    try:
        command = recognizer.recognize_google(audio).lower()
        print(f"🗣️ You said: {command}")
        return command
    except sr.UnknownValueError:
        print("❌ Could not understand the audio")
    except sr.RequestError:
        print("❌ API error")
    return None

if __name__ == "__main__":
    while True:
        command = recognize_speech()
        if command:
            if "turn on the light" in command:
                client.publish(topic, "ON")
                print("💡 Light turned ON!")
            elif "turn off the light" in command:
                client.publish(topic, "OFF")
                print("💡 Light turned OFF!")
            elif "jarvis exit" in command:
                print("👋 Exiting program...")
                break
